<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>EduSense Dashboard</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&family=Poppins:wght@600&display=swap" rel="stylesheet">
  
  <!-- Custom CSS -->
  <link rel="stylesheet" href="style.css">
  
  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js" defer></script>
  
  <!-- Font Awesome -->
  <script src="https://kit.fontawesome.com/your_kit_id.js" crossorigin="anonymous" defer></script>
  
  <meta name="color-scheme" content="light">
</head>
<body>
  <div class="d-flex min-vh-100">
    <!-- SIDEBAR -->
    <aside class="sidebar p-3" aria-label="Main sidebar">
      <div class="d-flex align-items-center gap-2 mb-4">
        <img src="assets/logo.png" alt="EduSense logo" class="sidebar-logo" onerror="this.style.display='none'">
        <div>
          <h6 class="mb-0">EduSense</h6>
          <small class="text-muted">Admin Panel</small>
        </div>
      </div>
      <nav class="nav flex-column" role="navigation" aria-label="Main navigation">
        <a class="nav-link active" href="http://localhost/Student-sentiment/admin/dashboard.php" aria-current="page"><i class="fa-solid fa-chart-pie me-2"></i> Dashboard</a>
        <a class="nav-link" href="http://localhost/Student-sentiment/frontend/feedback.html"><i class="fa-solid fa-comments me-2"></i> Feedback</a>
        <a class="nav-link" href="#trainingSection"><i class="fa-solid fa-database me-2"></i> Training Data</a>
      </nav>
      <div class="mt-auto">
        <button id="logoutBtn" class="btn btn-outline-secondary w-100" type="button">Logout</button>
      </div>
    </aside>

    <!-- MAIN CONTENT -->
    <main class="main-content p-4 flex-fill" id="dashboardMain" role="main">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="mb-0">Dashboard</h4>
        <div>
          <button id="refreshBtn" class="btn btn-sm btn-outline-primary me-2" type="button"><i class="fa-solid fa-arrows-rotate"></i> Refresh</button>
          <button id="downloadBtn" class="btn btn-sm btn-primary" type="button"><i class="fa-solid fa-download me-1"></i> Export CSV</button>
        </div>
      </div>

      <!-- Metrics Cards -->
      <div class="row gy-3 mb-3" id="metricsRow" aria-hidden="false">
        <div class="col-md-4">
          <div class="card-box p-3 text-center" role="region" aria-label="Positive count">
            <div class="small text-muted">Positive</div>
            <div class="h2 mt-2" id="positiveCount">0</div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card-box p-3 text-center" role="region" aria-label="Neutral count">
            <div class="small text-muted">Neutral</div>
            <div class="h2 mt-2" id="neutralCount">0</div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card-box p-3 text-center" role="region" aria-label="Negative count">
            <div class="small text-muted">Negative</div>
            <div class="h2 mt-2" id="negativeCount">0</div>
          </div>
        </div>
      </div>

      <!-- Charts and Tables -->
      <div class="row g-3">
        <div class="col-lg-6">
          <div class="chart-card p-3">
            <h6>Sentiment Distribution</h6>
            <canvas id="sentimentChart" height="180" aria-label="Sentiment distribution chart" role="img"></canvas>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="card p-3" id="feedbackSection">
            <h6>Recent Feedback</h6>
            <div id="feedbackTableWrapper" style="max-height:320px; overflow:auto;" aria-live="polite"></div>
          </div>
        </div>
        <div class="col-12">
          <div class="card p-3">
            <h6 id="trainingSection">Training Data (Sample)</h6>
            <div class="table-responsive">
              <table class="table table-sm" id="trainingTable" role="table" aria-describedby="trainingSection">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Gender</th>
                    <th scope="col">Income</th>
                    <th scope="col">Interest</th>
                    <th scope="col">Category</th>
                  </tr>
                </thead>
                <tbody></tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>

  <!-- Scripts -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" defer></script>
  <script src="script.js" defer></script>
</body>
</html>
